# MOMENTO Demo

Static single-page demo for the "The Story We Never Told" experience.

## Run
Open `index.html` in a browser.

## Deploy
Upload this folder to a static host such as Netlify or GitHub Pages.

## Notes
The demo currently uses remote Unsplash images and Google Fonts for the visual prototype.
Replace those URLs with the client's uploaded images when turning this into a real customer site.
